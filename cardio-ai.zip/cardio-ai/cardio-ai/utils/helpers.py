"""
helpers.py
-----------
Reusable helper functions and decorators used across the Flask app:
login-required / admin-required decorators, form validation helpers,
and small formatting utilities.
"""

import re
from functools import wraps
from flask import session, redirect, url_for, flash


def login_required(view_func):
    """Redirect to login page if the user is not authenticated."""
    @wraps(view_func)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return view_func(*args, **kwargs)
    return wrapped


def admin_required(view_func):
    """Restrict a view to admin users only."""
    @wraps(view_func)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        if not session.get("is_admin"):
            flash("Admin access required.", "danger")
            return redirect(url_for("dashboard"))
        return view_func(*args, **kwargs)
    return wrapped


def is_valid_email(email):
    pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    return re.match(pattern, email) is not None


def is_valid_password(password):
    """Require at least 6 characters for simplicity in this demo app."""
    return password is not None and len(password) >= 6


def risk_level_label(risk_percentage):
    """Return a human-friendly risk band label for a given percentage."""
    if risk_percentage >= 70:
        return "High Risk", "danger"
    elif risk_percentage >= 40:
        return "Moderate Risk", "warning"
    else:
        return "Low Risk", "success"
