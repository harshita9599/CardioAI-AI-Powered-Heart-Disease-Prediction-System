// main.js - Global JavaScript for CardioAI

document.addEventListener("DOMContentLoaded", function () {
  // Auto-dismiss flash messages after 4 seconds
  const alerts = document.querySelectorAll(".alert-auto-dismiss");
  alerts.forEach((alert) => {
    setTimeout(() => {
      const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
      if (bsAlert) bsAlert.close();
    }, 4000);
  });

  // Enable Bootstrap tooltips everywhere
  const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
  tooltipTriggerList.forEach((el) => new bootstrap.Tooltip(el));

  // Highlight active nav link based on current path
  const currentPath = window.location.pathname;
  document.querySelectorAll(".navbar-nav .nav-link, .dash-sidebar .nav-link").forEach((link) => {
    if (link.getAttribute("href") === currentPath) {
      link.classList.add("active");
    }
  });

  // Password confirmation live-check on register/settings forms
  const pw = document.getElementById("password") || document.getElementById("new_password");
  const confirmPw = document.getElementById("confirm_password");
  if (pw && confirmPw) {
    const checkMatch = () => {
      if (confirmPw.value.length === 0) {
        confirmPw.classList.remove("is-valid", "is-invalid");
        return;
      }
      if (pw.value === confirmPw.value) {
        confirmPw.classList.remove("is-invalid");
        confirmPw.classList.add("is-valid");
      } else {
        confirmPw.classList.remove("is-valid");
        confirmPw.classList.add("is-invalid");
      }
    };
    pw.addEventListener("input", checkMatch);
    confirmPw.addEventListener("input", checkMatch);
  }

  // Generic Bootstrap client-side validation trigger
  const forms = document.querySelectorAll(".needs-validation");
  Array.from(forms).forEach((form) => {
    form.addEventListener(
      "submit",
      (event) => {
        if (!form.checkValidity()) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add("was-validated");
      },
      false
    );
  });
});
