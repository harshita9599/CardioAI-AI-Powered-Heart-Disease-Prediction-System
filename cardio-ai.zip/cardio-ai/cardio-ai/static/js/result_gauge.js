// result_gauge.js - Renders a gauge-style doughnut chart for the risk % on the prediction result page

document.addEventListener("DOMContentLoaded", function () {
  const gaugeCanvas = document.getElementById("riskGaugeChart");
  if (!gaugeCanvas) return;

  const riskValue = parseFloat(gaugeCanvas.dataset.risk || "0");
  const color = riskValue >= 70 ? "#c62828" : riskValue >= 40 ? "#f9a825" : "#2e7d32";

  new Chart(gaugeCanvas.getContext("2d"), {
    type: "doughnut",
    data: {
      labels: ["Risk", "Remaining"],
      datasets: [
        {
          data: [riskValue, 100 - riskValue],
          backgroundColor: [color, "#e0e0e0"],
          borderWidth: 0,
        },
      ],
    },
    options: {
      responsive: true,
      circumference: 180,
      rotation: 270,
      cutout: "70%",
      plugins: {
        legend: { display: false },
        tooltip: { enabled: false },
      },
    },
  });
});
