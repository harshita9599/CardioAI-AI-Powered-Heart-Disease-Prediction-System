// dashboard_charts.js - Renders Chart.js visualizations on the Patient Dashboard

document.addEventListener("DOMContentLoaded", function () {
  const trendCanvas = document.getElementById("riskTrendChart");
  const distCanvas = document.getElementById("riskDistributionChart");

  if (!trendCanvas && !distCanvas) return;

  fetch("/api/dashboard-chart-data")
    .then((response) => response.json())
    .then((data) => {
      if (trendCanvas) renderTrendChart(data);
      if (distCanvas) renderDistributionChart(data);
    })
    .catch((err) => console.error("Failed to load chart data:", err));

  function renderTrendChart(data) {
    const ctx = trendCanvas.getContext("2d");
    new Chart(ctx, {
      type: "line",
      data: {
        labels: data.labels.length ? data.labels : ["No Data"],
        datasets: [
          {
            label: "Risk % Over Time",
            data: data.risk_values.length ? data.risk_values : [0],
            borderColor: "#d32f2f",
            backgroundColor: "rgba(211, 47, 47, 0.12)",
            tension: 0.35,
            fill: true,
            pointBackgroundColor: "#1565c0",
            pointRadius: 4,
          },
        ],
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: true, position: "top" },
          title: { display: false },
        },
        scales: {
          y: {
            beginAtZero: true,
            max: 100,
            title: { display: true, text: "Risk Percentage (%)" },
          },
          x: {
            ticks: { maxRotation: 45, minRotation: 30 },
          },
        },
      },
    });
  }

  function renderDistributionChart(data) {
    const ctx = distCanvas.getContext("2d");
    const dist = data.risk_distribution || { high: 0, low: 0 };
    new Chart(ctx, {
      type: "doughnut",
      data: {
        labels: ["High Risk", "Low Risk"],
        datasets: [
          {
            data: [dist.high, dist.low],
            backgroundColor: ["#c62828", "#2e7d32"],
            borderWidth: 0,
          },
        ],
      },
      options: {
        responsive: true,
        plugins: {
          legend: { position: "bottom" },
        },
        cutout: "65%",
      },
    });
  }
});
