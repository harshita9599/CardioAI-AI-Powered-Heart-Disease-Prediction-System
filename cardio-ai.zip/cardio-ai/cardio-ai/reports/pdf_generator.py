"""
pdf_generator.py
-----------------
Generates a professional PDF medical report for a given prediction
result using ReportLab.
"""

import io
from datetime import datetime

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
)
from reportlab.lib.enums import TA_CENTER, TA_LEFT


def generate_prediction_report(user, prediction):
    """
    Build a PDF report in-memory and return a BytesIO buffer ready to
    be sent to the client via Flask's send_file().

    Parameters
    ----------
    user : dict        -> user record (full_name, email, age, gender)
    prediction : dict  -> prediction record (all input fields + result)
    """
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=A4,
        topMargin=1.5 * cm, bottomMargin=1.5 * cm,
        leftMargin=2 * cm, rightMargin=2 * cm,
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "TitleStyle", parent=styles["Title"], fontSize=22,
        textColor=colors.HexColor("#d32f2f"), alignment=TA_CENTER, spaceAfter=4,
    )
    subtitle_style = ParagraphStyle(
        "SubtitleStyle", parent=styles["Normal"], fontSize=11,
        textColor=colors.HexColor("#555555"), alignment=TA_CENTER, spaceAfter=16,
    )
    section_style = ParagraphStyle(
        "SectionStyle", parent=styles["Heading2"], fontSize=13,
        textColor=colors.HexColor("#1565c0"), spaceBefore=14, spaceAfter=6,
    )
    normal_style = ParagraphStyle(
        "NormalStyle", parent=styles["Normal"], fontSize=10, alignment=TA_LEFT, leading=14,
    )

    elements = []

    # ---- Header ----
    elements.append(Paragraph("CardioAI", title_style))
    elements.append(Paragraph("AI-Powered Cardiac Risk Prediction Report", subtitle_style))
    elements.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#d32f2f")))
    elements.append(Spacer(1, 12))

    # ---- Patient Info ----
    elements.append(Paragraph("Patient Information", section_style))
    patient_data = [
        ["Full Name:", user.get("full_name", "-"), "Email:", user.get("email", "-")],
        ["Age:", str(user.get("age", "-")), "Gender:", str(user.get("gender", "-"))],
        ["Report Date:", datetime.now().strftime("%d %b %Y, %I:%M %p"), "Report ID:", f"#{prediction.get('id', '-')}"],
    ]
    patient_table = Table(patient_data, colWidths=[3 * cm, 5.5 * cm, 3 * cm, 5.5 * cm])
    patient_table.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 9.5),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTNAME", (2, 0), (2, -1), "Helvetica-Bold"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("TEXTCOLOR", (0, 0), (-1, -1), colors.HexColor("#333333")),
    ]))
    elements.append(patient_table)

    # ---- Clinical Input Data ----
    elements.append(Paragraph("Clinical Parameters Submitted", section_style))
    clinical_rows = [
        ["Parameter", "Value", "Parameter", "Value"],
        ["Age", prediction.get("age"), "Resting BP", f"{prediction.get('trestbps')} mm Hg"],
        ["Sex", "Male" if prediction.get("sex") == 1 else "Female", "Cholesterol", f"{prediction.get('chol')} mg/dl"],
        ["Chest Pain Type", prediction.get("cp"), "Fasting Blood Sugar", "High" if prediction.get("fbs") == 1 else "Normal"],
        ["Resting ECG", prediction.get("restecg"), "Max Heart Rate", prediction.get("thalach")],
        ["Exercise Angina", "Yes" if prediction.get("exang") == 1 else "No", "ST Depression", prediction.get("oldpeak")],
        ["ST Slope", prediction.get("slope"), "Major Vessels (ca)", prediction.get("ca")],
        ["Thalassemia", prediction.get("thal"), "", ""],
    ]
    clinical_table = Table(clinical_rows, colWidths=[4.25 * cm, 4.25 * cm, 4.25 * cm, 4.25 * cm])
    clinical_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1565c0")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cccccc")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f5f5f5")]),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
    ]))
    elements.append(clinical_table)

    # ---- Prediction Result ----
    elements.append(Paragraph("AI Prediction Result", section_style))
    risk_color = colors.HexColor("#c62828") if prediction.get("prediction") == 1 else colors.HexColor("#2e7d32")
    result_data = [
        ["Prediction:", prediction.get("prediction_label", "-")],
        ["Risk Percentage:", f"{prediction.get('risk_percentage')}%"],
        ["Confidence Score:", f"{prediction.get('confidence_score')}%"],
        ["Model Used:", prediction.get("model_name", "-")],
    ]
    result_table = Table(result_data, colWidths=[5 * cm, 11 * cm])
    result_table.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 11),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("TEXTCOLOR", (1, 0), (1, 0), risk_color),
        ("FONTNAME", (1, 0), (1, 0), "Helvetica-Bold"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))
    elements.append(result_table)

    # ---- Recommendations ----
    elements.append(Paragraph("Health Recommendations", section_style))
    recs = prediction.get("recommendations", [])
    for rec in recs:
        elements.append(Paragraph(f"&bull; {rec}", normal_style))
        elements.append(Spacer(1, 2))

    # ---- Disclaimer ----
    elements.append(Spacer(1, 20))
    elements.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#999999")))
    disclaimer_style = ParagraphStyle(
        "Disclaimer", parent=styles["Normal"], fontSize=8,
        textColor=colors.HexColor("#777777"), alignment=TA_CENTER, spaceBefore=8,
    )
    elements.append(Paragraph(
        "Disclaimer: This report is generated by an AI model for educational and "
        "informational purposes only. It is NOT a substitute for professional "
        "medical diagnosis. Please consult a licensed cardiologist for medical advice.",
        disclaimer_style,
    ))

    doc.build(elements)
    buffer.seek(0)
    return buffer
