"""
app.py
-------
CardioAI - AI Powered Cardiac Risk Prediction Platform
Main Flask application entry point.

Run with:
    python app.py
"""

import os
from datetime import datetime

from flask import (
    Flask, render_template, request, redirect, url_for,
    session, flash, send_file, jsonify
)

from models.db import init_db
from models import user as user_model
from models import prediction as prediction_model
from ml import predict as ml_predict
from reports.pdf_generator import generate_prediction_report
from utils.helpers import (
    login_required, admin_required, is_valid_email,
    is_valid_password, risk_level_label
)

# --------------------------------------------------------------------
# App configuration
# --------------------------------------------------------------------
app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("CARDIOAI_SECRET_KEY", "cardioai-dev-secret-key-change-in-production")
app.config["SESSION_PERMANENT"] = False

FEATURE_FIELDS = [
    "age", "sex", "cp", "trestbps", "chol", "fbs", "restecg",
    "thalach", "exang", "oldpeak", "slope", "ca", "thal",
]


# --------------------------------------------------------------------
# Template context processor - makes `current_user` info & year
# available in every template automatically.
# --------------------------------------------------------------------
@app.context_processor
def inject_globals():
    current_user = None
    if "user_id" in session:
        current_user = {
            "id": session.get("user_id"),
            "full_name": session.get("full_name"),
            "email": session.get("email"),
            "is_admin": session.get("is_admin", False),
        }
    return {"current_user": current_user, "current_year": datetime.now().year}


# --------------------------------------------------------------------
# Public pages
# --------------------------------------------------------------------
@app.route("/")
def home():
    return render_template("home.html")


@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/features")
def features():
    return render_template("features.html")


# --------------------------------------------------------------------
# Authentication
# --------------------------------------------------------------------
@app.route("/register", methods=["GET", "POST"])
def register():
    if "user_id" in session:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")
        age = request.form.get("age") or None
        gender = request.form.get("gender") or None
        phone = request.form.get("phone", "").strip() or None

        errors = []
        if not full_name:
            errors.append("Full name is required.")
        if not is_valid_email(email):
            errors.append("Please enter a valid email address.")
        if not is_valid_password(password):
            errors.append("Password must be at least 6 characters long.")
        if password != confirm_password:
            errors.append("Passwords do not match.")
        if user_model.get_user_by_email(email):
            errors.append("An account with this email already exists.")

        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("register.html", form_data=request.form)

        user_model.create_user(
            full_name=full_name, email=email, password=password,
            age=age, gender=gender, phone=phone,
        )
        flash("Registration successful! Please log in.", "success")
        return redirect(url_for("login"))

    return render_template("register.html", form_data={})


@app.route("/login", methods=["GET", "POST"])
def login():
    if "user_id" in session:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        user = user_model.get_user_by_email(email)
        if user and user_model.verify_password(user["password_hash"], password):
            session["user_id"] = user["id"]
            session["full_name"] = user["full_name"]
            session["email"] = user["email"]
            session["is_admin"] = bool(user["is_admin"])
            flash(f"Welcome back, {user['full_name']}!", "success")
            if user["is_admin"]:
                return redirect(url_for("admin_dashboard"))
            return redirect(url_for("dashboard"))

        flash("Invalid email or password.", "danger")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out successfully.", "info")
    return redirect(url_for("home"))


# --------------------------------------------------------------------
# Patient Dashboard
# --------------------------------------------------------------------
@app.route("/dashboard")
@login_required
def dashboard():
    user_id = session["user_id"]
    predictions = prediction_model.get_predictions_by_user(user_id)

    total_predictions = len(predictions)
    high_risk_count = sum(1 for p in predictions if p["prediction"] == 1)
    low_risk_count = total_predictions - high_risk_count
    latest = predictions[0] if predictions else None
    avg_risk = round(sum(p["risk_percentage"] for p in predictions) / total_predictions, 2) if total_predictions else 0

    return render_template(
        "dashboard.html",
        total_predictions=total_predictions,
        high_risk_count=high_risk_count,
        low_risk_count=low_risk_count,
        latest=latest,
        avg_risk=avg_risk,
        recent_predictions=predictions[:5],
    )


@app.route("/api/dashboard-chart-data")
@login_required
def dashboard_chart_data():
    """JSON endpoint feeding Chart.js on the dashboard page."""
    user_id = session["user_id"]
    predictions = prediction_model.get_predictions_by_user(user_id)
    predictions = list(reversed(predictions))  # chronological order

    labels = [p["created_at"] for p in predictions]
    risk_values = [p["risk_percentage"] for p in predictions]

    high_risk = sum(1 for p in predictions if p["prediction"] == 1)
    low_risk = len(predictions) - high_risk

    return jsonify({
        "labels": labels,
        "risk_values": risk_values,
        "risk_distribution": {"high": high_risk, "low": low_risk},
    })


# --------------------------------------------------------------------
# Prediction
# --------------------------------------------------------------------
@app.route("/predict", methods=["GET", "POST"])
@login_required
def predict():
    if request.method == "POST":
        try:
            input_data = {
                "age": int(request.form["age"]),
                "sex": int(request.form["sex"]),
                "cp": int(request.form["cp"]),
                "trestbps": int(request.form["trestbps"]),
                "chol": int(request.form["chol"]),
                "fbs": int(request.form["fbs"]),
                "restecg": int(request.form["restecg"]),
                "thalach": int(request.form["thalach"]),
                "exang": int(request.form["exang"]),
                "oldpeak": float(request.form["oldpeak"]),
                "slope": int(request.form["slope"]),
                "ca": int(request.form["ca"]),
                "thal": int(request.form["thal"]),
            }
        except (KeyError, ValueError):
            flash("Please fill in all fields with valid values.", "danger")
            return render_template("predict.html", form_data=request.form)

        result = ml_predict.predict_risk(input_data)
        prediction_id = prediction_model.save_prediction(session["user_id"], input_data, result)

        return redirect(url_for("prediction_result", prediction_id=prediction_id))

    return render_template("predict.html", form_data={})


@app.route("/prediction/<int:prediction_id>")
@login_required
def prediction_result(prediction_id):
    record = prediction_model.get_prediction_by_id(prediction_id, session["user_id"])
    if not record:
        flash("Prediction not found.", "danger")
        return redirect(url_for("history"))

    risk_label, risk_color = risk_level_label(record["risk_percentage"])
    return render_template(
        "prediction_result.html", record=record,
        risk_label=risk_label, risk_color=risk_color,
    )


# --------------------------------------------------------------------
# Prediction History
# --------------------------------------------------------------------
@app.route("/history")
@login_required
def history():
    user_id = session["user_id"]
    search = request.args.get("search", "").strip()
    risk_filter = request.args.get("risk_filter", "").strip()

    predictions = prediction_model.get_predictions_by_user(user_id)

    if risk_filter == "high":
        predictions = [p for p in predictions if p["prediction"] == 1]
    elif risk_filter == "low":
        predictions = [p for p in predictions if p["prediction"] == 0]

    if search:
        predictions = [
            p for p in predictions
            if search.lower() in p["created_at"].lower()
            or search.lower() in p["prediction_label"].lower()
            or search in str(p["id"])
        ]

    return render_template(
        "history.html", predictions=predictions,
        search=search, risk_filter=risk_filter,
    )


# --------------------------------------------------------------------
# Medical Reports (PDF)
# --------------------------------------------------------------------
@app.route("/reports")
@login_required
def reports():
    user_id = session["user_id"]
    predictions = prediction_model.get_predictions_by_user(user_id)
    return render_template("reports.html", predictions=predictions)


@app.route("/reports/<int:prediction_id>/download")
@login_required
def download_report(prediction_id):
    record = prediction_model.get_prediction_by_id(prediction_id, session["user_id"])
    if not record:
        flash("Report not found.", "danger")
        return redirect(url_for("reports"))

    user = user_model.get_user_by_id(session["user_id"])
    buffer = generate_prediction_report(user, record)

    filename = f"CardioAI_Report_{prediction_id}.pdf"
    return send_file(
        buffer, as_attachment=True, download_name=filename,
        mimetype="application/pdf",
    )


# --------------------------------------------------------------------
# Profile & Settings
# --------------------------------------------------------------------
@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    user_id = session["user_id"]

    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        age = request.form.get("age") or None
        gender = request.form.get("gender") or None
        phone = request.form.get("phone", "").strip() or None

        if not full_name:
            flash("Full name cannot be empty.", "danger")
        else:
            user_model.update_user_profile(user_id, full_name, age, gender, phone)
            session["full_name"] = full_name
            flash("Profile updated successfully.", "success")

        return redirect(url_for("profile"))

    user = user_model.get_user_by_id(user_id)
    predictions_count = len(prediction_model.get_predictions_by_user(user_id))
    return render_template("profile.html", user=user, predictions_count=predictions_count)


@app.route("/settings", methods=["GET", "POST"])
@login_required
def settings():
    user_id = session["user_id"]

    if request.method == "POST":
        current_password = request.form.get("current_password", "")
        new_password = request.form.get("new_password", "")
        confirm_password = request.form.get("confirm_password", "")

        user = user_model.get_user_by_id(user_id)

        if not user_model.verify_password(user["password_hash"], current_password):
            flash("Current password is incorrect.", "danger")
        elif not is_valid_password(new_password):
            flash("New password must be at least 6 characters long.", "danger")
        elif new_password != confirm_password:
            flash("New passwords do not match.", "danger")
        else:
            user_model.update_password(user_id, new_password)
            flash("Password updated successfully.", "success")

        return redirect(url_for("settings"))

    return render_template("settings.html")


# --------------------------------------------------------------------
# Admin Dashboard
# --------------------------------------------------------------------
@app.route("/admin")
@admin_required
def admin_dashboard():
    total_users = user_model.count_users()
    total_predictions = prediction_model.count_predictions()
    high_risk_predictions = prediction_model.count_high_risk_predictions()
    model_info = ml_predict.get_model_info()

    recent_predictions = prediction_model.get_all_predictions()[:10]
    recent_users = user_model.get_all_users()[:5]

    return render_template(
        "admin_dashboard.html",
        total_users=total_users,
        total_predictions=total_predictions,
        high_risk_predictions=high_risk_predictions,
        model_info=model_info,
        recent_predictions=recent_predictions,
        recent_users=recent_users,
    )


@app.route("/admin/users")
@admin_required
def admin_users():
    users = user_model.get_all_users()
    return render_template("admin_users.html", users=users)


@app.route("/admin/users/<int:user_id>/delete", methods=["POST"])
@admin_required
def admin_delete_user(user_id):
    if user_id == session["user_id"]:
        flash("You cannot delete your own admin account.", "danger")
    else:
        user_model.delete_user(user_id)
        flash("User deleted successfully.", "success")
    return redirect(url_for("admin_users"))


@app.route("/admin/predictions")
@admin_required
def admin_predictions():
    predictions = prediction_model.get_all_predictions()
    return render_template("admin_predictions.html", predictions=predictions)


# --------------------------------------------------------------------
# Error Handlers
# --------------------------------------------------------------------
@app.errorhandler(404)
def not_found_error(error):
    return render_template("errors/404.html"), 404


@app.errorhandler(500)
def internal_error(error):
    return render_template("errors/500.html"), 500


@app.errorhandler(403)
def forbidden_error(error):
    return render_template("errors/403.html"), 403


# --------------------------------------------------------------------
# App bootstrap
# --------------------------------------------------------------------
def bootstrap_app():
    """Initialize the database and ensure a default admin account exists."""
    init_db()

    admin_email = "admin@cardioai.com"
    if not user_model.get_user_by_email(admin_email):
        user_model.create_user(
            full_name="System Administrator",
            email=admin_email,
            password="admin123",
            age=40, gender="Other", phone=None, is_admin=1,
        )
        print(f"Default admin account created -> {admin_email} / admin123")


bootstrap_app()


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
