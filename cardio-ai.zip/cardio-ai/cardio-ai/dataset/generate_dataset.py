"""
generate_dataset.py
--------------------
Generates a realistic, UCI-style Heart Disease dataset (heart.csv).

NOTE ON DATA SOURCE:
This environment has no internet access, so the original UCI Cleveland
Heart Disease CSV could not be downloaded directly. Instead, this script
programmatically builds a dataset that:
  1. Uses the EXACT same 13 input features + 1 target column as the
     real UCI Heart Disease dataset (same column names, same value
     ranges/encodings).
  2. Generates feature values from realistic medical distributions
     (age, cholesterol, blood pressure, etc.).
  3. Computes the target ("heart disease present or not") using a
     clinically-inspired risk scoring rule plus random noise, so the
     relationships between features and the target are realistic and
     learnable by machine learning models.

If you have internet access, you can replace `dataset/heart.csv` with
the original UCI Cleveland dataset (same column layout) and everything
else in this project (training, prediction, app) will keep working
without any code changes.

Columns (standard UCI Heart Disease layout):
    age       - age in years
    sex       - 1 = male, 0 = female
    cp        - chest pain type (0-3)
    trestbps  - resting blood pressure (mm Hg)
    chol      - serum cholesterol (mg/dl)
    fbs       - fasting blood sugar > 120 mg/dl (1 = true, 0 = false)
    restecg   - resting electrocardiographic results (0-2)
    thalach   - maximum heart rate achieved
    exang     - exercise induced angina (1 = yes, 0 = no)
    oldpeak   - ST depression induced by exercise relative to rest
    slope     - slope of the peak exercise ST segment (0-2)
    ca        - number of major vessels colored by fluoroscopy (0-4)
    thal      - thalassemia (0 = normal, 1 = fixed defect, 2 = reversible defect)
    target    - 1 = heart disease present, 0 = not present
"""

import numpy as np
import pandas as pd
import os

RANDOM_SEED = 42
N_SAMPLES = 1000


def generate_heart_disease_dataset(n_samples=N_SAMPLES, seed=RANDOM_SEED):
    rng = np.random.default_rng(seed)

    age = rng.integers(29, 78, n_samples)
    sex = rng.integers(0, 2, n_samples)
    cp = rng.integers(0, 4, n_samples)
    trestbps = rng.integers(94, 201, n_samples)
    chol = rng.integers(126, 565, n_samples)
    fbs = rng.choice([0, 1], size=n_samples, p=[0.85, 0.15])
    restecg = rng.integers(0, 3, n_samples)
    thalach = rng.integers(71, 203, n_samples)
    exang = rng.choice([0, 1], size=n_samples, p=[0.68, 0.32])
    oldpeak = np.round(rng.uniform(0, 6.2, n_samples), 1)
    slope = rng.integers(0, 3, n_samples)
    ca = rng.integers(0, 5, n_samples)
    thal = rng.integers(0, 3, n_samples)

    # ---- Clinically-inspired risk score used to derive the target ----
    risk_score = np.zeros(n_samples)
    risk_score += (age > 54) * 1.2
    risk_score += (sex == 1) * 0.8
    risk_score += (cp == 0) * 1.1                 # typical angina -> higher risk
    risk_score += (trestbps > 140) * 1.0
    risk_score += (chol > 240) * 1.0
    risk_score += (fbs == 1) * 0.4
    risk_score += (restecg != 0) * 0.5
    risk_score += (thalach < 120) * 1.3
    risk_score += (exang == 1) * 1.4
    risk_score += (oldpeak > 2) * 1.3
    risk_score += (slope == 2) * 0.9
    risk_score += (ca >= 1) * 1.5
    risk_score += (thal == 2) * 1.2

    noise = rng.normal(0, 1.3, n_samples)
    final_score = risk_score + noise

    threshold = np.median(final_score)
    target = (final_score > threshold).astype(int)

    df = pd.DataFrame({
        "age": age,
        "sex": sex,
        "cp": cp,
        "trestbps": trestbps,
        "chol": chol,
        "fbs": fbs,
        "restecg": restecg,
        "thalach": thalach,
        "exang": exang,
        "oldpeak": oldpeak,
        "slope": slope,
        "ca": ca,
        "thal": thal,
        "target": target,
    })

    return df


if __name__ == "__main__":
    df = generate_heart_disease_dataset()
    out_path = os.path.join(os.path.dirname(__file__), "heart.csv")
    df.to_csv(out_path, index=False)
    print(f"Dataset generated: {out_path}")
    print(f"Shape: {df.shape}")
    print(f"Target distribution:\n{df['target'].value_counts()}")
