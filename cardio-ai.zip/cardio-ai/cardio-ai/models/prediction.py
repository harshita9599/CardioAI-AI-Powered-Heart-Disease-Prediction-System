"""
prediction.py
--------------
Data-access functions for the `predictions` table.
"""

import json
from models.db import get_db


def save_prediction(user_id, input_data, result):
    """Save a prediction record combining raw input data and ML result."""
    conn = get_db()
    try:
        cursor = conn.execute(
            """INSERT INTO predictions
               (user_id, age, sex, cp, trestbps, chol, fbs, restecg, thalach,
                exang, oldpeak, slope, ca, thal, prediction, prediction_label,
                risk_percentage, confidence_score, model_name, recommendations)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                user_id,
                input_data["age"], input_data["sex"], input_data["cp"],
                input_data["trestbps"], input_data["chol"], input_data["fbs"],
                input_data["restecg"], input_data["thalach"], input_data["exang"],
                input_data["oldpeak"], input_data["slope"], input_data["ca"],
                input_data["thal"],
                result["prediction"], result["prediction_label"],
                result["risk_percentage"], result["confidence_score"],
                result["model_name"], json.dumps(result["recommendations"]),
            ),
        )
        conn.commit()
        return cursor.lastrowid
    finally:
        conn.close()


def get_predictions_by_user(user_id):
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT * FROM predictions WHERE user_id = ? ORDER BY created_at DESC",
            (user_id,),
        ).fetchall()
        results = []
        for row in rows:
            item = dict(row)
            item["recommendations"] = json.loads(item["recommendations"] or "[]")
            results.append(item)
        return results
    finally:
        conn.close()


def get_prediction_by_id(prediction_id, user_id=None):
    conn = get_db()
    try:
        if user_id is not None:
            row = conn.execute(
                "SELECT * FROM predictions WHERE id = ? AND user_id = ?",
                (prediction_id, user_id),
            ).fetchone()
        else:
            row = conn.execute(
                "SELECT * FROM predictions WHERE id = ?", (prediction_id,)
            ).fetchone()
        if row:
            item = dict(row)
            item["recommendations"] = json.loads(item["recommendations"] or "[]")
            return item
        return None
    finally:
        conn.close()


def get_all_predictions():
    conn = get_db()
    try:
        rows = conn.execute(
            """SELECT predictions.*, users.full_name, users.email
               FROM predictions
               JOIN users ON predictions.user_id = users.id
               ORDER BY predictions.created_at DESC"""
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        conn.close()


def count_predictions():
    conn = get_db()
    try:
        row = conn.execute("SELECT COUNT(*) as cnt FROM predictions").fetchone()
        return row["cnt"]
    finally:
        conn.close()


def count_high_risk_predictions():
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT COUNT(*) as cnt FROM predictions WHERE prediction = 1"
        ).fetchone()
        return row["cnt"]
    finally:
        conn.close()


def delete_prediction(prediction_id, user_id):
    conn = get_db()
    try:
        conn.execute(
            "DELETE FROM predictions WHERE id = ? AND user_id = ?",
            (prediction_id, user_id),
        )
        conn.commit()
    finally:
        conn.close()
