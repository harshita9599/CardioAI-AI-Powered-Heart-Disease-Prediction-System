"""
db.py
------
SQLite database connection helper for CardioAI.
Provides a simple `get_db()` connection factory and an `init_db()`
function that creates all required tables from database/schema.sql.
"""

import os
import sqlite3

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "database", "cardio.db")
SCHEMA_PATH = os.path.join(BASE_DIR, "database", "schema.sql")


def get_db():
    """Return a new sqlite3 connection with row access by column name."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """Create the database file and tables if they don't already exist."""
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = get_db()
    with open(SCHEMA_PATH, "r") as f:
        conn.executescript(f.read())
    conn.commit()
    conn.close()
