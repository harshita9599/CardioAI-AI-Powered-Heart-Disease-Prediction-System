"""
user.py
--------
Data-access functions for the `users` table.
"""

from werkzeug.security import generate_password_hash, check_password_hash
from models.db import get_db


def create_user(full_name, email, password, age=None, gender=None, phone=None, is_admin=0):
    """Insert a new user with a securely hashed password."""
    conn = get_db()
    password_hash = generate_password_hash(password)
    try:
        cursor = conn.execute(
            """INSERT INTO users (full_name, email, password_hash, age, gender, phone, is_admin)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (full_name, email, password_hash, age, gender, phone, is_admin),
        )
        conn.commit()
        return cursor.lastrowid
    finally:
        conn.close()


def get_user_by_email(email):
    conn = get_db()
    try:
        row = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def get_user_by_id(user_id):
    conn = get_db()
    try:
        row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def verify_password(stored_hash, password):
    return check_password_hash(stored_hash, password)


def update_user_profile(user_id, full_name, age, gender, phone):
    conn = get_db()
    try:
        conn.execute(
            """UPDATE users SET full_name = ?, age = ?, gender = ?, phone = ?
               WHERE id = ?""",
            (full_name, age, gender, phone, user_id),
        )
        conn.commit()
    finally:
        conn.close()


def update_password(user_id, new_password):
    conn = get_db()
    try:
        password_hash = generate_password_hash(new_password)
        conn.execute("UPDATE users SET password_hash = ? WHERE id = ?", (password_hash, user_id))
        conn.commit()
    finally:
        conn.close()


def get_all_users():
    conn = get_db()
    try:
        rows = conn.execute("SELECT * FROM users ORDER BY created_at DESC").fetchall()
        return [dict(row) for row in rows]
    finally:
        conn.close()


def count_users():
    conn = get_db()
    try:
        row = conn.execute("SELECT COUNT(*) as cnt FROM users").fetchone()
        return row["cnt"]
    finally:
        conn.close()


def delete_user(user_id):
    conn = get_db()
    try:
        conn.execute("DELETE FROM predictions WHERE user_id = ?", (user_id,))
        conn.execute("DELETE FROM users WHERE id = ?", (user_id,))
        conn.commit()
    finally:
        conn.close()
