"""
train_model.py
----------------
Trains multiple ML classifiers on the Heart Disease dataset, compares
their performance, and saves the best-performing model (plus the
feature scaler) to disk using joblib so the Flask app can load and
use them for real-time predictions.

Run with:
    python ml/train_model.py
"""

import os
import json
import joblib
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
)

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATASET_PATH = os.path.join(BASE_DIR, "dataset", "heart.csv")
MODEL_DIR = os.path.join(BASE_DIR, "ml", "saved_models")
FEATURE_COLUMNS = [
    "age", "sex", "cp", "trestbps", "chol", "fbs", "restecg",
    "thalach", "exang", "oldpeak", "slope", "ca", "thal",
]
TARGET_COLUMN = "target"


def load_data():
    if not os.path.exists(DATASET_PATH):
        raise FileNotFoundError(
            f"Dataset not found at {DATASET_PATH}. "
            "Run `python dataset/generate_dataset.py` first."
        )
    df = pd.read_csv(DATASET_PATH)
    X = df[FEATURE_COLUMNS]
    y = df[TARGET_COLUMN]
    return X, y


def get_models():
    """Return a dict of model_name -> sklearn estimator to train/compare."""
    return {
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
        "Decision Tree": DecisionTreeClassifier(max_depth=6, random_state=42),
        "Random Forest": RandomForestClassifier(
            n_estimators=200, max_depth=8, random_state=42
        ),
        "SVM": SVC(kernel="rbf", probability=True, random_state=42),
    }


def evaluate_model(model, X_test, y_test):
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    return {
        "accuracy": round(accuracy_score(y_test, y_pred) * 100, 2),
        "precision": round(precision_score(y_test, y_pred) * 100, 2),
        "recall": round(recall_score(y_test, y_pred) * 100, 2),
        "f1_score": round(f1_score(y_test, y_pred) * 100, 2),
        "roc_auc": round(roc_auc_score(y_test, y_proba) * 100, 2),
        "confusion_matrix": confusion_matrix(y_test, y_pred).tolist(),
    }


def train_and_compare():
    os.makedirs(MODEL_DIR, exist_ok=True)

    print("=" * 60)
    print("CardioAI - Model Training & Comparison")
    print("=" * 60)

    X, y = load_data()

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # Scale features - required for Logistic Regression & SVM,
    # harmless for tree-based models.
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    models = get_models()
    results = {}
    trained_models = {}

    for name, model in models.items():
        print(f"\nTraining: {name} ...")
        model.fit(X_train_scaled, y_train)
        metrics = evaluate_model(model, X_test_scaled, y_test)
        results[name] = metrics
        trained_models[name] = model
        print(
            f"  Accuracy: {metrics['accuracy']}%  |  "
            f"F1: {metrics['f1_score']}%  |  ROC-AUC: {metrics['roc_auc']}%"
        )

    # Pick best model based on F1 score (balances precision & recall,
    # important for medical predictions where both false positives and
    # false negatives matter).
    best_model_name = max(results, key=lambda n: results[n]["f1_score"])
    best_model = trained_models[best_model_name]
    best_metrics = results[best_model_name]

    print("\n" + "=" * 60)
    print(f"BEST MODEL: {best_model_name}")
    print(f"Metrics: {best_metrics}")
    print("=" * 60)

    # Save the best model, the scaler, and metadata about all models.
    joblib.dump(best_model, os.path.join(MODEL_DIR, "best_model.pkl"))
    joblib.dump(scaler, os.path.join(MODEL_DIR, "scaler.pkl"))

    metadata = {
        "best_model_name": best_model_name,
        "feature_columns": FEATURE_COLUMNS,
        "all_results": results,
        "best_metrics": best_metrics,
    }
    with open(os.path.join(MODEL_DIR, "model_metadata.json"), "w") as f:
        json.dump(metadata, f, indent=4)

    print(f"\nModel artifacts saved to: {MODEL_DIR}")
    return metadata


if __name__ == "__main__":
    train_and_compare()
