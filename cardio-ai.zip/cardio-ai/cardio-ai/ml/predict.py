"""
predict.py
-----------
Loads the trained model + scaler produced by train_model.py and
provides a simple `predict_risk()` function used by the Flask app to
turn raw patient form input into a prediction, risk percentage,
confidence score, and health recommendations.
"""

import os
import json
import joblib
import numpy as np
import pandas as pd

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_DIR = os.path.join(BASE_DIR, "ml", "saved_models")

MODEL_PATH = os.path.join(MODEL_DIR, "best_model.pkl")
SCALER_PATH = os.path.join(MODEL_DIR, "scaler.pkl")
METADATA_PATH = os.path.join(MODEL_DIR, "model_metadata.json")

FEATURE_COLUMNS = [
    "age", "sex", "cp", "trestbps", "chol", "fbs", "restecg",
    "thalach", "exang", "oldpeak", "slope", "ca", "thal",
]

_model = None
_scaler = None
_metadata = None


def _load_artifacts():
    """Lazy-load model artifacts once and cache them in module globals."""
    global _model, _scaler, _metadata

    if _model is None or _scaler is None:
        if not (os.path.exists(MODEL_PATH) and os.path.exists(SCALER_PATH)):
            raise FileNotFoundError(
                "Trained model not found. Please run "
                "`python ml/train_model.py` before starting the app."
            )
        _model = joblib.load(MODEL_PATH)
        _scaler = joblib.load(SCALER_PATH)

    if _metadata is None and os.path.exists(METADATA_PATH):
        with open(METADATA_PATH, "r") as f:
            _metadata = json.load(f)

    return _model, _scaler, _metadata


def get_model_info():
    """Return metadata about the currently loaded model (name + metrics)."""
    _, _, metadata = _load_artifacts()
    if metadata:
        return {
            "model_name": metadata.get("best_model_name", "Unknown"),
            "metrics": metadata.get("best_metrics", {}),
        }
    return {"model_name": "Unknown", "metrics": {}}


def _generate_recommendations(input_data, risk_percentage):
    """Generate simple, human-readable health recommendations based on
    the submitted patient data and the predicted risk level."""
    tips = []

    if risk_percentage >= 70:
        tips.append("Your predicted risk is HIGH. Please consult a cardiologist as soon as possible.")
    elif risk_percentage >= 40:
        tips.append("Your predicted risk is MODERATE. Consider scheduling a check-up with your doctor.")
    else:
        tips.append("Your predicted risk is LOW. Keep up your healthy habits!")

    if input_data.get("chol", 0) > 240:
        tips.append("Your cholesterol level is high. Reduce saturated fat and consider a lipid panel test.")

    if input_data.get("trestbps", 0) > 140:
        tips.append("Your resting blood pressure is elevated. Monitor it regularly and reduce salt intake.")

    if input_data.get("fbs", 0) == 1:
        tips.append("Your fasting blood sugar is high. Consider screening for diabetes.")

    if input_data.get("thalach", 200) < 120:
        tips.append("Your maximum heart rate is on the lower side. Discuss an exercise stress test with your doctor.")

    if input_data.get("exang", 0) == 1:
        tips.append("You reported exercise-induced angina. Avoid strenuous activity until evaluated by a physician.")

    if input_data.get("age", 0) > 54:
        tips.append("Regular cardiac screening is recommended for your age group.")

    tips.append("Maintain a balanced diet, exercise regularly, avoid smoking, and manage stress levels.")

    return tips


def predict_risk(input_data: dict):
    """
    Predict heart disease risk for a single patient.

    Parameters
    ----------
    input_data : dict
        Dictionary containing the 13 required feature values, e.g.
        {"age": 55, "sex": 1, "cp": 2, "trestbps": 130, "chol": 246,
         "fbs": 0, "restecg": 1, "thalach": 150, "exang": 0,
         "oldpeak": 1.5, "slope": 2, "ca": 0, "thal": 2}

    Returns
    -------
    dict with keys: prediction (0/1), prediction_label, risk_percentage,
    confidence_score, recommendations, model_name
    """
    model, scaler, metadata = _load_artifacts()

    # Build feature vector in the exact order the model was trained on.
    # Using a DataFrame (with the same column names used during training)
    # avoids scikit-learn's "X does not have valid feature names" warning.
    features_df = pd.DataFrame(
        [[float(input_data[col]) for col in FEATURE_COLUMNS]],
        columns=FEATURE_COLUMNS,
    )
    features_scaled = scaler.transform(features_df)

    prediction = int(model.predict(features_scaled)[0])
    probabilities = model.predict_proba(features_scaled)[0]

    risk_percentage = round(float(probabilities[1]) * 100, 2)
    confidence_score = round(float(max(probabilities)) * 100, 2)

    recommendations = _generate_recommendations(input_data, risk_percentage)

    model_name = metadata.get("best_model_name", "ML Model") if metadata else "ML Model"

    return {
        "prediction": prediction,
        "prediction_label": "High Risk" if prediction == 1 else "Low Risk",
        "risk_percentage": risk_percentage,
        "confidence_score": confidence_score,
        "recommendations": recommendations,
        "model_name": model_name,
    }
